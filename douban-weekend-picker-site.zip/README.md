# 豆瓣周末抽片机

一个可部署到 GitHub Pages 的静态网页小工具。

## 使用

直接打开 index.html 即可使用。

## 部署到 GitHub Pages

1. 新建一个 GitHub 仓库。
2. 上传这个文件夹里的所有内容。
3. 在 GitHub 仓库 Settings > Pages 里，选择 Deploy from a branch，分支选 main，目录选 /root。
4. 等待 GitHub 生成网址。
